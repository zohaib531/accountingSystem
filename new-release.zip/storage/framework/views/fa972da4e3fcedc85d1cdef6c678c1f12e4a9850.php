<?php $__env->startSection('title','Journal Voucher List'); ?>


<?php $__env->startSection('content'); ?>

    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <div class="row m-0">
                            <div class="col-6 text-right">
                                <h4 class="card-title">All Journal Voucher</h4>
                            </div>
                            <div class="col-6 text-right">
                                <a href="<?php echo e(route('journal.create')); ?>">
                                    <button type="button" class="btn btn-primary">
                                        Add new +
                                    </button>
                                </a>
                            </div>
                        </div>

                        <div class="d-flex justify-content-end px-3 mt-4">
                            <a class="btn btn-success text-white" href="<?php echo e(route('journalReport')); ?>">Export to PDF</a>
                        </div>

                        <div class="table-responsive">
                            <table class="table table-striped table-bordered zero-configuration">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Voucher Id</th>
                                        <th>Date</th>
                                        <th>Sub account</th>
                                        <th>Naration</th>
                                        <th>Debit</th>
                                        <th>Credit</th>
                                        
                                    </tr>
                                </thead>partyAccount
                                <tbody>
                                    <?php
                                        $num = 0;
                                    ?>
                                    <?php $__currentLoopData = $vouchers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $voucherDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(isset($voucherDetail->voucher->voucher_type) && $voucherDetail->voucher->voucher_type=='journal_voucher'): ?>
                                        <tr>
                                            <td><?php echo e(++$num); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('journal.edit',$voucherDetail->voucher->id)); ?>">
                                                    <?php echo e($voucherDetail->voucher_id); ?>

                                                </a>
                                            </td>
                                            <td><?php echo e(date('d/m/y',strtotime($voucherDetail->date))); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('partyAccount')); ?>">
                                                    <?php echo e($voucherDetail->subAccount->title); ?>

                                                </a>
                                            </td>
                                            <td><?php echo e($voucherDetail->product_narration); ?></td>
                                            
                                            <?php if($voucherDetail->entry_type =='debit'): ?>
                                                <td><?php echo e(number_format($voucherDetail->debit_amount)); ?></td>
                                            <?php else: ?>
                                                <td>0.00</td>
                                            <?php endif; ?>
                                            

                                            
                                            <?php if($voucherDetail->entry_type == 'credit'): ?>
                                                <td><?php echo e(number_format($voucherDetail->credit_amount)); ?></td>
                                            <?php else: ?>
                                                <td>0.00</td>
                                            <?php endif; ?>
                                            

                                            
                                        </tr>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/template/plugins/tables/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/template/plugins/tables/js/datatable/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/template/plugins/tables/js/datatable-init/datatable-basic.min.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\accountsSystem\new-release\resources\views/admin/vouchers/list/journal.blade.php ENDPATH**/ ?>