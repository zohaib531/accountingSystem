<?php $__env->startSection('title', 'Sale/Purchase Voucher List'); ?>

<?php $__env->startSection('content'); ?>

    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <form method="post" id="filterForm" action="">
                            <?php echo csrf_field(); ?>
                            <div class="row m-0">
                                <div class="col-6 text-right">
                                    <h4 class="card-title">All Sale/Purchase Voucher</h4>
                                </div>
                                <div class="col-6 text-right">
                                    <a href="<?php echo e(route('salePurchase.create')); ?>">
                                        <button type="button" class="btn btn-primary">
                                            Add new +
                                        </button>
                                    </a>
                                </div>
                                
                                <div class="col-10">
                                    <div class="row mt-2 align-items-end">
                                        <div class="col-3">
                                            <label class="col-lg-12 col-form-label px-0">Start Date<span class="text-danger">*</span></label>
                                            <div class="col-lg-12 px-0">
                                                
                                                <input name="start_date" id="val-start_date" class="form-control <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('start_date') != null ? old('start_date') : $start_date); ?>" placeholder="dd/mm/yy" onkeyup="date_reformat_dd(this);" onkeypress="date_reformat_dd(this);" onpaste="date_reformat_dd(this);" autocomplete="off" type="text">

                                                <?php if($errors->has('start_date')): ?>
                                                    <span class="text-danger">Please start end date.</span>
                                                <?php else: ?>
                                                    <span class="fade">Some Data</span>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                        <div class="col-3">
                                            <label class="col-lg-12 col-form-label px-0" for="val-end_date">End date<span class="text-danger">*</span></label>
                                            <div class="col-lg-12 px-0">
                                                <input name="end_date" id="val-end_date"  class="form-control  <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('end_date')  != null ? old('end_date') : $end_date); ?>"  placeholder="dd/mm/yy" onkeyup="date_reformat_dd(this);" onkeypress="date_reformat_dd(this);" onpaste="date_reformat_dd(this);" autocomplete="off" type="text">
                                                <?php if($errors->has('end_date')): ?>
                                                    <span class="text-danger">Please enter end date.</span>
                                                <?php else: ?>
                                                    <span class="fade">Some Data</span>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                        <div class="col-3">
                                            <label class="col-lg-12 col-form-label px-0">Product Type<span class="text-danger">*</span></label>
                                            <select class="form-control searchableSelectFilterProductType" name="product_type" onchange="productChange(this)">
                                                <option selected value="all">All</option>
                                                <?php $__currentLoopData = $unique_product_titles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($product->title); ?>"  <?php if(in_array($product->title , $filterElementsArr)): ?> selected <?php endif; ?>><?php echo e($product->title); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <span class="fade">Some Data</span>
                                        </div>
                                    </div>

                                    <div class="row align-items-end">
                                        <div class="col-3">
                                            <label class="col-lg-12 col-form-label px-0">Sub Account<span class="text-danger">*</span></label>
                                            <select name="sub_account_id" class="form-control searchableSelectFilterSubaccount">
                                                <option <?php if(isset($filterElementsArr[3]) && $filterElementsArr[3] == 'all'): ?> selected <?php endif; ?> selected value="all">All</option>
                                                <?php $__currentLoopData = $subAccounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subAccount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($subAccount->id); ?>" <?php if(isset($filterElementsArr[3]) && $filterElementsArr[3] == $subAccount->id): ?> selected <?php endif; ?>><?php echo e($subAccount->title); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>

                                        <div class="col-3">
                                            <label class="col-lg-12 col-form-label px-0">Product<span class="text-danger">*</span></label>
                                            <select name="product_narration" id="productWithFilter" class="form-control searchableSelectFilterProduct">
                                                <option selected value="all" >All</option>
                                                <?php if(isset($filterElementsArr[2]) && $filterElementsArr[2] != 'all'): ?>
                                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if(in_array($product->title , $filterElementsArr) ): ?>
                                                            <option value="<?php echo e($product->title." - ".$product->narration." - ".$product->product_unit); ?>"  <?php if(in_array($product->title." - ".$product->narration." - ".$product->product_unit , $filterElementsArr)): ?> selected <?php endif; ?>><?php echo e($product->title." - ".$product->narration." - ".$product->product_unit); ?></option>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php else: ?>
                                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($product->title." - ".$product->narration." - ".$product->product_unit); ?>"  <?php if(in_array($product->title." - ".$product->narration." - ".$product->product_unit , $filterElementsArr)): ?> selected <?php endif; ?>><?php echo e($product->title." - ".$product->narration." - ".$product->product_unit); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>

                                            </select>
                                        </div>

                                        <div class="col-3">
                                            <label class="col-lg-12 col-form-label px-0">Transaction Type<span class="text-danger">*</span></label>
                                            <select name="entry_type" class="form-control searchableSelectFilterTransaction">
                                                <option selected value="all">All</option>
                                                <option value="debit" <?php if(in_array('debit', $filterElementsArr)): ?> selected <?php endif; ?>>Debit</option>
                                                <option value="credit" <?php if(in_array('credit', $filterElementsArr)): ?> selected <?php endif; ?>>Credit</option>
                                            </select>
                                        </div>

                                        <div class="col-3 text-center">
                                            <button type="button" onclick="exportAndApplyFilter(this,'<?php echo e(route('applyFilter')); ?>')" class="btn btn-primary">Apply Filter</button>
                                            <a href="<?php echo e(route('salePurchase.index')); ?> "  class="<?php echo e(Request::is('applyFilter') ? 'd-inline' : 'd-none'); ?>">
                                                <button type="button" class="btn btn-danger">Refresh Filter</button>
                                            </a>
                                        </div>

                                    </div>
                                </div>
                                

                            </div>

                            <div class="d-flex justify-content-end px-3 ">
                                <button type="button" onclick="exportAndApplyFilter(this,'<?php echo e(route('salePurchaseReport')); ?>')" class="btn btn-success text-white">Export to PDF</button>
                            </div>
                        </form>

                        <div class="table-responsive">
                            <table class="table table-striped table-bordered zero-configuration">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Voucher Id</th>
                                        <th>Date</th>
                                        <th>Sub account</th>
                                        <th>Product</th>
                                        <th>Quantity</th>
                                        <th>Rate</th>
                                        <th>Debit</th>
                                        <th>Credit</th>
                                        
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $num = 0;
                                        $totalQuantity = 0;
                                        $totalDebit = 0;
                                        $totalCredit = 0;
                                    ?>
                                    <?php $__currentLoopData = $vouchers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $voucherDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(isset($voucherDetail->voucher->voucher_type) && $voucherDetail->voucher->voucher_type=='sale_purchase_voucher'): ?>
                                            <?php
                                                $totalQuantity += $voucherDetail->quantity;
                                                $voucherDetail->entry_type =='debit' ? $totalDebit += $voucherDetail->debit_amount : $totalCredit += $voucherDetail->credit_amount ;
                                            ?>

                                            <tr>
                                                <td><?php echo e(++$num); ?></td>
                                                <td>
                                                    <a href="<?php echo e(route('salePurchase.edit',$voucherDetail->voucher->id)); ?>">
                                                        <?php echo e($voucherDetail->voucher_id); ?>

                                                    </a>
                                                </td>
                                                <td><?php echo e(date('d/m/y',strtotime($voucherDetail->date))); ?></td>
                                                <td>
                                                    <a href="<?php echo e(route('partyAccount')); ?>">
                                                        <?php echo e($voucherDetail->subAccount['title']); ?>

                                                    </a>
                                                </td>
                                                <td><?php echo e($voucherDetail->product_narration); ?></td>
                                                <td><?php echo e($voucherDetail->quantity); ?></td>
                                                <td><?php echo e($voucherDetail->rate); ?></td>
                                                
                                                <?php if($voucherDetail->entry_type =='debit'): ?>
                                                    <td><?php echo e(number_format($voucherDetail->debit_amount)); ?></td>
                                                <?php else: ?>
                                                    <td>0.00</td>
                                                <?php endif; ?>
                                                

                                                
                                                <?php if($voucherDetail->entry_type == 'credit'): ?>
                                                    <td><?php echo e(number_format($voucherDetail->credit_amount)); ?></td>
                                                <?php else: ?>
                                                    <td>0.00</td>
                                                <?php endif; ?>
                                                

                                                
                                            </tr>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>

                                <tfoot>
                                    <tr>
                                        <td colspan="5"><h4 class="mb-0 text-center">Total</h4></td>
                                        <td><?php echo e(number_format($totalQuantity)); ?></td>
                                        <td></td>
                                        <td><?php echo e(number_format($totalDebit)); ?></td>
                                        <td><?php echo e(number_format($totalCredit)); ?></td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/template/plugins/tables/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/template/plugins/tables/js/datatable/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/template/plugins/tables/js/datatable-init/datatable-basic.min.js')); ?>"></script>


    <script>

        function exportAndApplyFilter(elem,targetUrl){
            let targetElement = $('#filterForm');
            targetElement.attr("action",targetUrl);
            targetElement.submit();
        }

        $(document).ready(function() {
            $('.searchableSelectFilterSubaccount').select2({dropdownParent: $('.searchableSelectFilterSubaccount').parent()});
            $('.searchableSelectFilterProduct').select2({dropdownParent: $('.searchableSelectFilterProduct').parent()});
            $('.searchableSelectFilterTransaction').select2({dropdownParent: $('.searchableSelectFilterTransaction').parent()});
            $('.searchableSelectFilterProductType').select2({dropdownParent: $('.searchableSelectFilterProductType').parent()});
        });

        // const productChange = (e) => {
        //     // productWithFilter.innerHTML = '<option selected value="all" >All</option>';
        //     let html = '<option selected value="all" >All</option>';
        //     let newSingleHTML = '';

        //     var allproduct = <?php echo $products; ?>;
        //     for(let singleProduct of allproduct){
        //         if(e.value == 'all'){
        //             html +=`<option value="${singleProduct.title} - ${singleProduct.narration} - ${singleProduct.product_unit}" >${singleProduct.title} - ${singleProduct.narration} - ${singleProduct.product_unit}</option>`;
        //         }
        //         if(e.value == singleProduct.title){

        //             newSingleHTML +=`<option value="${singleProduct.title} - ${singleProduct.narration} - ${singleProduct.product_unit}" >${singleProduct.title} - ${singleProduct.narration} - ${singleProduct.product_unit}</option>`;

        //         }

        //     }

        //     e.value == 'all' ? productWithFilter.innerHTML = html : productWithFilter.innerHTML = newSingleHTML;
        // }


        const productChange = (e) => {
            let html = '<option selected value="all" >All</option>';
            var allproduct = <?php echo $products; ?>;
            for(let singleProduct of allproduct){
                if(e.value == 'all'){
                    html +=`<option value="${singleProduct.title} - ${singleProduct.narration} - ${singleProduct.product_unit}" >${singleProduct.title} - ${singleProduct.narration} - ${singleProduct.product_unit}</option>`;
                }
                if(e.value == singleProduct.title){
                    html +=`<option value="${singleProduct.title} - ${singleProduct.narration} - ${singleProduct.product_unit}" >${singleProduct.title} - ${singleProduct.narration} - ${singleProduct.product_unit}</option>`;
                }
            }
            productWithFilter.innerHTML= html;
        }
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\accountsSystem\new-release\resources\views/admin/vouchers/list/salePurchase.blade.php ENDPATH**/ ?>