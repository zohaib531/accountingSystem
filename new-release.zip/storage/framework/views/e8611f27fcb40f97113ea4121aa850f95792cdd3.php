<div>
    <div class="d-flex justify-content-end mb-4">
        <a class="btn btn-success text-white" href="<?php echo e(route('partyAccountReport',[$subAccount->id,$startDate, $endDate])); ?>">Export to PDF</a>
    </div>

    <div class="table-responsive">

        <table class="table table-striped table-bordered zero-configuration">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Narration/Details</th>
                    <th>Debit</th>
                    <th>Credit</th>
                    <th>Balance</th>
                    <th>Status</th>
                    <th class="text-center">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $openingBalance = 0;
                    $entryType = '';

                ?>
                <?php if(isset($vouchers) && $vouchers->count()>0): ?>
                    <?php $__currentLoopData = $vouchers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($loop->first): ?>
                            <?php
                                // $getOpeningBalanceResponse = getOpeningBalance($detail->sub_account_id, null, $detail->date , true , $detail->id);
                                $getOpeningBalanceResponse = getOpeningBalance($detail->sub_account_id, null, $startDate, true , $detail->id);
                                $openingBalance = $getOpeningBalanceResponse["opening_balance"];
                                $entryType = $getOpeningBalanceResponse["opening_balance_type"];
                            ?>
                            <tr>
                                <td><?php echo e(date('d/m/y',strtotime($startDate))); ?></td>
                                <td>Opening Balance</td>
                                <td></td>
                                <td></td>
                                <td><?php echo e(number_format(getOpeningBalance($detail->sub_account_id, null, $startDate, true , $detail->id)["opening_balance"])); ?></td>
                                <td><?php echo e(getOpeningBalance($detail->sub_account_id, null, $startDate, true , $detail->id)["opening_balance_type"]); ?></td>
                                
                                <td></td>
                            </tr>
                        <?php endif; ?>
                        <?php
                            $str = $detail->entry_type."_amount";
                            $getBalanceAndTypeResponse = getBalanceAndType($openingBalance,$entryType,$detail->entry_type,$detail->$str);
                            $openingBalance = $getBalanceAndTypeResponse["balance"];
                            $entryType = $getBalanceAndTypeResponse["type"];
                            $voucher = $detail->voucher->voucher_type;
                            $voucherType = $voucher=="sale_purchase_voucher"? 'salePurchase.edit': 'journal.edit';
                        ?>
                        <tr>
                            <td><?php echo e(date('d/m/y',strtotime($detail->date))); ?></td>
                            <td><?php echo e($detail->product_narration); ?> <?php if($detail->quantity!=0 && $detail->rate!=0): ?>  (<span style="font-weight:bold;"><?php echo e($detail->quantity); ?> x <?php echo e($detail->rate); ?></span>) <?php endif; ?></td>
                            <td><?php echo e($detail->debit_amount!=0?number_format($detail->debit_amount):""); ?></td>
                            <td><?php echo e($detail->credit_amount!=0?number_format($detail->credit_amount):""); ?></td>
                            <td><?php echo e(number_format($openingBalance)); ?></td>
                            <td><?php echo e($entryType); ?></td>
                            <td class="text-center">
                                <a href="<?php echo e(route($voucherType,$detail->voucher_id)); ?>">
                                    <button class="btn btn-info btn-sm">Update</button>
                                </a>
                            </td>
                        </tr>
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php else: ?>

                    <?php
                        // $endDate =  $_POST['end_date'];
                        // $accound_id = $_POST['sub_account'];
                        // $getOpeningBalanceResponse = getOpeningBalance($subAccount->id,$startDate, $endDate  , false , 0);

                        $getOpeningBalanceResponse = getOpeningBalance($subAccount->id, $startDate, $endDate  , false , 0);
                        $openingBalance = $getOpeningBalanceResponse["opening_balance"];
                        $entryType = $getOpeningBalanceResponse["opening_balance_type"];
                    ?>


                    <tr>
                        <td><?php echo e(Carbon\Carbon::createFromFormat('y-m-d', $endDate)->format('d / m / y')); ?></td>
                        
                        <td>Opening Balance</td>
                        <td></td>
                        <td></td>
                        <td><?php echo e(number_format($openingBalance)); ?></td>
                        <td><?php echo e($entryType); ?></td>
                        <td></td>
                    </tr>

                    <tr>
                        <td colspan="7" class="text-center">No records found</td>
                    </tr>
                <?php endif; ?>
            </tbody>
            <?php if(isset($vouchers) && $vouchers->count()>0): ?>
                <tfoot>
                    <tr>
                        <td></td>
                        <td><h5 class="text-center">Total</h5></td>
                        <td><?php echo e(number_format($totalDebit)); ?></td>
                        <td><?php echo e(number_format($totalCredit)); ?></td>
                        <td><?php echo e(number_format($openingBalance)); ?></td>
                        <td><?php echo e($entryType); ?></td>
                        <td></td>
                    </tr>
                </tfoot>
            <?php endif; ?>
        </table>

        <script>
            $(document).ready(function() {
                $('.zero-configuration').DataTable({ "ordering": false });
            });
        </script>



    </div>
</div>


<?php /**PATH C:\xampp\htdocs\accountsSystem\new-release\resources\views/admin/reports/partyAccountLedger/get_data.blade.php ENDPATH**/ ?>