<table class="table table-striped table-bordered zero-configuration">
    <thead>
        <tr>
            <th>Date</th>
            <th>Days</th>
            <th>Narration/Details</th>
            <th>Debit</th>
            <th>Credit</th>
            <th>Balance</th>
            <th>Nature (Debit/Credit)</th>
            
        </tr>
    </thead>
    <tbody>
        <?php
            $openingBalance = 0;
            $debitBalance = 0;
            $creditBalance = 0;
            $entryType = '';
        ?>
        <?php if(isset($vouchers) && $vouchers->count()>0): ?>
            <?php $__currentLoopData = $vouchers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$singleAccount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $subAccount = App\SubAccount::where('id',$key)->first();
                    $recordEntryType = '';
                    $array = json_decode(json_encode($singleAccount), true);
                    $reverseArray = array_reverse($array);
                ?>

                <?php if($subAccount->opening_balance != 0): ?>
                    <tr><td colspan="7"> <h3 class="mb-0"><?php echo e($subAccount->title); ?></h3></td></tr>
                <?php endif; ?>

                <?php $__currentLoopData = $reverseArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($loop->first): ?>
                        <?php
                            $getOpeningBalanceResponse = getOpeningBalance($detail['sub_account_id'],$detail['date'],true,$detail['id']);
                            $openingBalance = $getOpeningBalanceResponse["opening_balance"];
                            $entryType = $getOpeningBalanceResponse["opening_balance_type"];
                            $recordEntryType = $getOpeningBalanceResponse["opening_balance_type"];

                        ?>
                        <?php if($openingBalance != 0): ?>
                             <tr>
                                <td><?php echo e(date('d/m/y',strtotime($detail['date']))); ?></td>
                                <td></td>
                                <td>Opening Balance</td>
                                <td colspan="2"></td>
                                <td><?php echo e(number_format(getOpeningBalance($detail['sub_account_id'],$detail['date'],true,$detail['id'])["opening_balance"])); ?></td>
                                <td><?php echo e(getOpeningBalance($detail['sub_account_id'],$detail['date'],true,$detail['id'])["opening_balance_type"]); ?></td>
                            </tr>
                        <?php endif; ?>
                    <?php endif; ?>

                    <?php if($recordEntryType == $detail['entry_type'] && $openingBalance != 0): ?>

                        <?php
                            $str = $detail['entry_type']."_amount";
                            if($openingBalance > 0){
                                $detail['entry_type']=="debit"?$debitBalance += $detail[$str]:$creditBalance += $detail[$str];
                                $openingBalance = $openingBalance - $detail[$str];
                                if($openingBalance < 0 && $recordEntryType == 'debit'){
                                    $recordEntryType = 'credit';
                                }else{
                                    $recordEntryType = 'debit';
                                }
                            }else{
                                $entryType = $entryType=="debit"? "credit":"debit";
                            }
                            $to = \Carbon\Carbon::createFromFormat('Y-m-d', $detail['date']);
                            $from = \Carbon\Carbon::createFromFormat('Y-m-d', date('Y-m-d'));
                            $diff_in_days = $to->diffInDays($from);
                        ?>

                        <tr>
                            <td><?php echo e(date('d/m/y',strtotime($detail['date']))); ?></td>
                            <td><?php echo e($diff_in_days); ?></td>
                            <td><?php echo e($detail['product_narration']); ?> <?php if($detail['quantity']!=0 && $detail['rate']!=0): ?>  (<span style="font-weight:bold;"><?php echo e($detail['quantity']); ?> x <?php echo e($detail['rate']); ?></span>) <?php endif; ?></td>
                            <td><?php echo e($detail['debit_amount']!=0? number_format($detail['debit_amount']) :""); ?></td>
                            <td><?php echo e($detail['credit_amount']!=0? number_format($detail['credit_amount']):""); ?></td>
                            <td><?php echo e(number_format(abs($openingBalance))); ?></td>
                            <td><?php echo e($recordEntryType); ?></td>
                        </tr>
                        <?php if($openingBalance < 0): ?>
                            <?php break; ?>
                        <?php endif; ?>

                    <?php endif; ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php else: ?>
            <tr>
                <td colspan="8" class="text-center">No records found</td>
            </tr>
        <?php endif; ?>
    </tbody>


    
</table>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/template/plugins/tables/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/template/plugins/tables/js/datatable/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/template/plugins/tables/js/datatable-init/datatable-basic.min.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php /**PATH C:\xampp\htdocs\accountsSystem\new-release\resources\views/admin/reports/agingReport/get_data.blade.php ENDPATH**/ ?>