<?php $__env->startSection('title','Dashboard'); ?>
<?php $__env->startSection('content'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\accountsSystem\new-release\resources\views/admin/index.blade.php ENDPATH**/ ?>